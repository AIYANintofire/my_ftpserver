# Change Log
All enhancements and patches to Cookiecutter Django will be documented in this file.
This project adheres to [Semantic Versioning](http://semver.org/).

## [2019-07-09]
### Fixed
- Always use test settings in pytest (@danihodovic)
- Remove gunicorn from `INSTALLED_APPS` (@danihodovic)
- Remove `EMAIL_HOST` and `EMAIL_PORT` with locmem backend (@danihodovic)

### Added
- Add `EMAIL_TIMEOUT` (@danihodovic)

## [2019-06-22]
### Fixed
- Remove redundant template debug setting (@danihodovic)

## [2019-06-19]
### Fixed
- Fix removal carriage returns in docker scripts (@timclaessens)

## [2019-06-15]
### Fixed
- Issue with Pycharm setup for running things in Docker compose (@foarsitter)

## [2019-06-06]
### Changed
- Update generated Travis config (@browniebroke)

## [2019-06-03]
### Added
- Installed `django-celery-beat` to keep scheduled tasks in DB (@keyvanm)

## [2019-05-28]
### Changed
- Use GCP acronym rather than inconsistent GCE/GCS (@tanoabeleyra)

## [2019-05-27]
### Changed
- Made cloud provider optional (@tanoabeleyra)
- Updated to Django 2.2.1 (@browniebroke)

### Fixed
- Celery worker-related setting names (@browniebroke)

## [2019-05-18]
### Removed
- Remove the user list view (@browniebroke)

### Fixed 
- Static storage default ACL (@browniebroke)

## [2019-05-17]
### Fixed
- Added `LocaleMiddleware` to the list of middlewares (@tanoabeleyra)
- Added `LOCALE_PATH` to settings (@tanoabeleyra)

## [2019-05-16]
### Changed
- Users app to have a translated verbose name (@tanoabeleyra)
- Logging configuration for local (@browniebroke)

## [2019-05-08]
### Changed
- Upgraded to Django 2.1 (@browniebroke)

## [2019-04-07]
### Added
- Support for Google Cloud Storage (@ahhda)

## [2019-04-03]
### Added
- Command to backup Db to AWS S3 (@foarsitter)

## [2019-03-25]
### Added
- Node image to run Gulp with Docker (@browniebroke)

## [2019-03-19]
### Changed
- Replaced Caddy with Traefik (@demestav)

## [2019-03-11]
### Changed
- Sentry integration from Raven to Sentry-SDK (@gfabricio)
- Made Redis config conditional on Celery locally (@demestav) 

## [2019-03-11]
### Added
- Automatic migrations on Heroku (@yunti)

## [2019-03-06]
### Fixed
- Missing script tag in Travis config (@btknu)

## [2019-03-02]
### Changed
- Celery eager setting in local setting with Docker (@keithjeb)

## [2019-03-01]
### Updated
- All NPM dependencies (@takkaria)

## [2018-11-13]
### Changed
- Security settings in Dev (@carlmjohnson)

## [2018-11-20]
### Fixed
- Passing the CSRF header from the reverse proxy to Django server for DRF (@hpbruna)

## [2018-11-12]
### Fixed
- Initialisation of Celery app (@glasslion)

## [2018-10-24]
### Fixed
- Persisting of iPython history between sessions (@davitovmasyan)

### Added
- Postgres 10.5 option (@jleclanche)

## [2018-09-18]
### Added
- Included `mypy` in dependencies and run it in tests (@apirobot)

## [2018-09-18]
### Fixed
- Avoid `$` in environment variables to workaround a bug from django-environ (@browniebroke)

## [2018-09-16]
### Fixed
- Bug in ordering of Middleware for production config (@ChrisPappalardo)

## [2018-09-12]
### Fixed
- URLs for Static and Media for S3 buckets in regions other than N. Virginia (@umrashrf)

## [2018-09-09]
### Changed
- Name of static and media storage classes (@sfdye)

## [2018-09-01]
### Changed
- Make static and media storage fully-fledged classes (@erfaan)

## [2018-08-28]
### Fixed
- Running tests in docker test script (@apirobot)

## [2018-07-23]
### Changed
- Test commands to use pytest (@jcass77)

### Removed 
- Some hacks leftovers from Bootstrap v4 beta in `project.js` (@hendrikschneider)

## [2018-07-12]
### Changed
- Upgraded to Bootstrap 4.1.1 (@mostaszewski)

## [2018-06-25]
### Added
- Flower integration with Docker (@webyneter)

## [2018-06-25]
### Changed
- Rewrite user app test to use a pytest style (@webyneter)

## [2018-06-21]
### Added
- Extend & update Celery config (@webyneter & @apirobot)

## [2018-05-25]
### Fixed
- Build issues due to incompatibility between libressl & openssl (@SassanoM)

## [2018-05-21]
### Changed
- Updated Caddy to 0.11 and pin its version (@webyneter)

## [2018-05-14]
### Changed
- Replace `awesome-slugify` by `python-slugify` (@hongquan)
- Migrate to Django 2.0+ URL style (@saschalalala)

## [2018-05-05]
### Fixed
- Postgres backup & restore commands (@webyneter)

## [2018-04-10]
### Changed
- Simplify configuration (@danidee10)

## [2018-04-08]
### Added
- Adopt Black code style (@pydanny)

## [2018-03-27]
### Fixed
- Simplified extra Celery config generated when opted out (@webyneter)

## [2018-03-21]
### Removed
- Remove Opbeat support (@sfdye)

## [2018-03-16]
### Fixed
- Install `psycopg2-binary` when using Docker locally (@browniebroke)

## [2018-03-14]
### Fixed
- Fixed and improved Postgres backup & restore scripts (@webyneter)

## [2018-03-10]
### Changed
- Simplify Mailgun setting (@browniebroke)

## [2018-03-06]
### Changed
- Convert string formatting to f-strings (@sfdye)

## [2018-03-01]
### Changed
- Celery to use JSON serialization by default (@adammsteele)
- Use Docker version from Travis to run tests (@browniebroke)

## [2018-02-16]
### Changed
- Upgraded to Django 2.0 (@epicwhale)

## [2018-01-15]
### Changed
- Removed Elastic Beanstalk support (@pydanny)

## [2017-12-28]
### Changed
- Upgraded to Django 1.11 (@pydanny)

## [2017-10-08]
### Changed
- Elastic Beanstalk: Added --noinput to migrate command (@MightySCollins )

## [2017-10-07]
### Added
- Finished first pass at Elastic Beanstalk docs (@pydanny & @audreyr)
### Deleted
- Removed Heroku instant deploy button (@pydanny)


##[2016-09-29]
### Added
- Added default `AUTH_PASSWORD_VALIDATORS` configuration, generated by django 1.10 startproject. See [Password Validation docs](https://docs.djangoproject.com/en/1.10/topics/auth/passwords/#module-django.contrib.auth.password_validation") (@luzfcb)
- Rename `MIDDLEWARE_CLASSES` to `MIDDLEWARE` to enable support to [new style middleware](https://github.com/django/deps/blob/master/final/0005-improved-middleware.rst) introduced in Django 1.10 (@luzfcb)
- New setting `MAILGUN_SENDER_DOMAIN` to allow sending mail from any domain other than those registered with mailgun (@jangeador)
- add `urlpatterns` configuration to django-debug-toolbar, because the automatic configuration of `urlpatterns` was removed from django-debug-toolbar (@luzfcb)
- Added Temporary workaround on `requirements/local.txt` to fix django-debug-toolbar issue: https://github.com/pydanny/cookiecutter-django/issues/827 (@luzfcb)

### Changed
- Upgrade to Django 1.10.1 (@luzfcb)
- Upgrade django-model-utils to 2.6, django-redis to 4.5.0, redis to 2.10.5, Sphinx to 1.4.6, pytest-django to 3.0.0, django-anymail to 0.5, raven to 5.27.1, whitenoise to 3.2.2 (@luzfcb)
- Upgrade to Bootstrap 4 Alpha 4, jQuery to 3.1.1, tether.js to 1.3.7 (@luzfcb)
- Update `manage.py` to use same code of `manage.py` from Django 1.10 (@luzfcb)
- Sync `sites` app migrations with django 1.10, and fix aditional migrations to `sites` and `user` app (@luzfcb)
d changed 'admin' url on `config/urls.py`, to stay the same as generated by django 1.10 (@luzfcb)
- Make test_docker.sh tests pass by passing new password auth rules (@ssteinerx)

### Removed
- Removed django-autoslug because not support django 1.10 at this date (@luzfcb)


##[2016-09-10]
### Changed
- Use app registry instead of INSTALLED_APPS to discover celery tasks (@dhepper)
- PEP8 imports fix (@aleprovencio)

### Removed
- Removed django-floppyforms (@pydanny)

##[2016-09-08]
### Removed
- Webpack support, see #774 (@ssteinerx)

##[2016-08-10]
## Added
- PostgreSQL versions are now selectable, instead of defaulting to 9.5; the minimum version is 9.2, which is supported by [Heroku](https://devcenter.heroku.com/articles/heroku-postgresql#version-support-and-legacy-infrastructure) and Django (@burhan)
- Fixed minor issue in the README.rst (@burhan)

##[2016-08-03]
## Changed
- Upgrade to Bootstrap 4 Alpha 3 and its dependencies, including jQuery (@audreyr)

##[2016-06-25]
## Changed
- use `https` instead `ssh` to clone [cookiecutter-webpack](https://github.com/hzdg/cookiecutter-webpack) if `Webpack` is selected as `JS Task Runner` - fix issue #647 (@luzfcb and @resakse)

##[2016-06-24]
## Added
- Settings file for running tests faster (@audreyr)
- Add GPLv3 licence support (@cgaspoz)

## Changed
- Makes the database backups compressed. restores compressed backups (@jangeador)
- Review and edit django-allauth templates (@kappataumu)

##[2016-06-19]
## Added
- Webpack as an option (@goldhand)

##[2016-06-17]
## Added
- django-compressor support (@andresgz)
- Debian Jessie OS Requirements (@ddiazpinto)

##[2016-06-14]
### Changed
- Move Docker backups to their own section (@pydanny)

##[2016-06-13]
### Changed
- Use latest redis image in Docker (@pydanny)
- Documentation cleanup and corrections (@audreyr)

##[2016-06-12]
### Changed
- Documentation cleanup and corrections (@kappataumu)

##[2016-06-11]
### Changed
- Enhancements to the developing locally docs (@antoniablair)

##[2016-06-06]
### Changed
- Pin Bootstrap CSS and JS to v4.0.0-alpha.2, use minified versions

##[2016-06-05]
### Added
- Configurable admin for users (@pydanny, @jayfk, @dezoito)

##[2016-06-04]
### Added
- Let's Encrypt automation and instruction (@mjsisley and @chrisdev)

##[2016-06-03]
### Added
- Documentation for debugging with Docker (@mjsisley)
- Apache 2 License option in `cookiecutter.json` (@dot2dotseurat)
- Removed unnecessary version check from `pre_gen_project.py` (@suledev)
- Add gulp alternative as a js task runner and fix navbar style issue (@viviangb and @xpostudio4)

### Deleted
- AngularJS (@pydanny)
- django-secure (@xpostudio4)

##[2016-06-02]
### Added
- Added better instructions for installing postgres on Mac OS X (@dot2dotseurat )

##[2016-05-22]
### Added
- Added instructions for copying backups from docker to host (@phiberjenz)
- Added mailhog docker container (@noisy)

##[2016-05-15]
### Added
- Added GitLab continuous integration article to README.rst (@dezoito)

## [2016-05-13]
### Changed
- Update version of pyflakes to 1.2.3, django-extensions to 1.6.7 and gunicorn to 19.5.0 (@luzfcb)
- Update version of AngularJS to 1.5.5 (@luzfcb)

### Removed
- Remove Raven 404 catch middleware. Fix #367 (@pydanny)

## [2016-05-09]
### Changed
- Improved mailhog usage documentation on `developing-locally.rst`  (@shireenrao)
- Replaced all `readthedocs.org` referencies to point to the new domain `readthedocs.io` (@luzfcb)
- Update version of pyflakes (@luzfcb)

## [2016-05-08]
### Changed
- Updated whitenoise configuration to match changes in version 3.0 (@trungdong)

## [2016-05-07]
### Added
- Added Ubuntu 16.04 dependencies on a new dependency file `requirements.apt.xenial` (@raonyguimaraes)

### Changed
- Small improvements in ``install_os_dependencies.sh`` support new dependency file (@raonyguimaraes)

## [2016-05-06]
### Changed
- Update version of pyflakes (@pydanny)

## [2016-05-03]
### Changed
- Update version of Django, django-extensions, django-mailgun (@luzfcb)

### [2016-05-01]
### Changed
- Restored the Pycharm project configuration files, that was accidentally removed in [15f350f](https://github.com/pydanny/cookiecutter-django/commit/15f350f05e2b49b4bdff0bdaa2b2ff260606e0f6) (@luzfcb @Newton715)

### [2016-04-30]
### Changed
- Small fixes to utility scripts (@scast)

### [2016-04-26]
### Added
- Instructions on how to install PythonAnywhere. (@hjwp)

### [2016-04-25]
### Added
- Check to confirm that the user has a modern version of Cookiecutter. (@pydanny)

### Removed
- Removed hitch per #529 (@pydanny)

### [2016-04-20]
### Changed
- Default to today's date in cookiecutter.json. (@audreyr)
- Change repo_name to project_slug for clarity. (@audreyr)
- Transform project name to lowercase for slug. (@audreyr)

### [2016-04-19]
### Added
- "Got Questions?" section in our README.rst. Yes, there is now a cookiecutter-django tag on Stack Overflow! (@pydanny)

### Changed
- Update usage instructions with new prompts, minor cleanup (@audreyr)

### [2016-04-18]
### Added
- removing duplication of depends_on in docker-compose.yml (@noisy)

### [2016-04-17]
### Added
- "Built with Cookiecutter Django" badge to generated project README (@audreyr)
- New introductory article (@krzysztofzuraw)

### Changed
- Quote consistency, single quotes everywhere! (@blopker)

### [2016-04-15]
### Changed
- Major project generation cleanup (@jayfk)

### Removed
- Deleting unnecessary .idea dir from MAIN directory (@noisy)

### [2016-04-14]
### Added
- Added typecheck in .pylintrc to fix pylint-django gets "no-member" error (@solvire)

### Changed
- Downgrading python-dateutil to version 2.4.2 because pykwalify==1.5.0 (required by HitchTest) uses a [pinned version of python-dateutil](https://github.com/Grokzen/pykwalify/blob/1.5.0/setup.py#L31) (@noisy)
- Update Pillow version to 3.2.0 (security fix) (@luzfcb)

### [2016-04-12]
### Changed
- celeryworker and celerybeat missing the correct dockerfile (@jayfk)

### [2016-04-08]
### Changed
- Move to named docker volumes (@jayfk)

### [2016-04-07]
### Changed
- Pycharm Support (including debugging in Docker) @noisy
- Set the correct License @epileptic-fish

### [2016-03-23]
### Changed
- Fixed issue on LICENSE file generation (@romanosipenko)
- In install_python_dependencies.sh file, Fixed wrong reference to python3 if use_python2 was set to y (@luzfcb @noisy)

### [2016-03-16]
### Changed
- Set the correct postgres username in dev.yml (@calculuscowboy)

## [2016-03-14]
### Changed
- Enforce `repo_name` as proper python module (@catherinedevlin)

## [2016-03-08]
### Changed
- Docker configuration now uses docker-compose format v2 (@aeikenberry)
- Make sure that STATIC_URL != MEDIA_URL (@cdvv7788)
- fix minor typos in project README (@menzenski)
- Updated docker docs (@jayfk)

### Added
- Added database controls for docker (@jayfk)


## [2016-03-05]
### Changed
- Update version of Django, celery, django-test-plus (@luzfcb)
- Update version of Hitch tests dependencies: jupyter_client (@luzfcb)
- Update 'now' date in cookiecutter.json (@luzfcb)
- Update the usage example in README (@luzfcb)

## [2016-03-01]
### Changed
- Update version of Django, flake8, pyflakes, pytest, factory_boy, ipdb, Werkzeug, gevent (@luzfcb)
- Update version of Hitch tests dependencies: click, hitchserve, hitchsystem, hitchtest, ipython, psutil, python-dateutil(@luzfcb)
- Update Tether (JS) version to 1.2.0 (@luzfcb)

## [2016-02-24]
### Added
- Beginning support for `py.test` (@pydanny)

### Changed
- Fixed missing div closing tag for "container" on user_list.html (@Eraldo)

## [2016-02-18]
### Changed
- The status of the registration (open or closed) is now read from the project environment instead of hardcoded in the common settings file. (@Eraldo)
- Renamed the adapter.py file to adapters.py to match the django naming convention. (@Eraldo)



## [2016-02-15]
### Changed
- In `users` app adapter, fix `is_open_for_signup` missing parameter (@oryx2)
- Fixes and improvements in Hitch tests , see [#485](https://github.com/pydanny/cookiecutter-django/pull/485) (@crdoconnor)


## [2016-02-12]
### Changed
- Fixed typo (@yunti)

## [2016-02-07]
### Changed
- In `users` app, use Django 1.9 `LoginRequiredMixin` instead of django-braces implementation (@yunti)
- Update native OS libraries of Hitch Test, because [unixpackage](https://github.com/unixpackage/unixpackage) now supports multiple versions of same Linux distribution (@crdoconnor)
- Update AngularJS version to 1.5.0 (@luzfcb)
- Update version of wheel, Pillow, django_coverage_plugin (@luzfcb)
- Update version of Hitch tests dependencies: decorator, hitchselenium, ipython, ptyprocess, selenium (@luzfcb)
- Provided options for FOSS license choices, or for private efforts, no written license (@pydanny)

## [2016-02-01]
### Changed
- Update version of Django and django-floppyforms (@luzfcb)
- Update version of Hitch tests dependencies: hitchpython and selenium (@luzfcb)

## [2016-01-30]
### Changed
- Update flake8 to 2.5.2 (@luzfcb)

## [2016-01-29]
### Changed
- Update AngularJS version to 1.4.9 (@luzfcb)
- Update jQuery version to 2.2.0 (@luzfcb)
- Update 'now' date in cookiecutter.json (@luzfcb)
- Update version of boto, celery, django_coverage_plugin, django-storages-redux, flake8, gevent, gunicorn, pep8, pytest, tox, Werkzeug (@luzfcb)
- Update version of Hitch tests dependencies: colorama, decorator, hitchpostgres, hitchpython, hitchredis, hitchselenium, hitchserve, hitchsystem, hitchtest, ipython, patool, pickleshare, psutil, python-build, requests, selenium, tblib, traitlets (@luzfcb)


## [2016-01-26]
### Changed
- Fixed NEW_RELIC_APP_NAME environment variable (@jayfk)

## [2016-1-18]
### Added
- Added .dockerignore file (@bogdal)
- Docker tests for travis (@jayfk)

### Changed
- Removed the $-sign from allowed chars to generate the secret key (@jayfk)

## [2016-01-17]
### Added
- Adding a section on third party articles referencing `cookiecutter-django` (@mjheo)

### Changed
- Add celerybeat db to gitignore (@originell)

## [2016-01-16]
### Added
- Adding an explanation for having `django.contrib.sites`. (@pydanny)


## [2016-01-13]
### Changed
- Update setup.py version to 1.9.1 to match Django version. (@Collederas)
- Require Wheel 0.26.0. Needed to install certain packages on CPython 3.5+ like Pillow and psycopg2 (@audreyr)

## [2016-01-09]
### Changed
- Upgraded django-extensions to 1.6.1 as it fixes a [JSONField bug](https://github.com/django-extensions/django-extensions/blob/master/CHANGELOG.md#161) (@burhan)
- Upgraded Pillow to version 3.1.0 ([upstream changelog](https://github.com/python-pillow/Pillow/blob/master/CHANGES.rst#310-2016-01-04)) (@burhan)
- Upgraded django to 1.9.1 to integrate various [bugfixes](https://docs.djangoproject.com/en/1.9/releases/1.9.1/) (@burhan)
- Upgraded django-crispy-forms to 1.6 for [BS4 and django 1.9 compatibility fixes](https://github.com/maraujop/django-crispy-forms/blob/dev/CHANGELOG.md#160-201617) (@burhan)
- Upgraded django-model-utils to 2.4, to enable [support for django 1.9](https://github.com/carljm/django-model-utils/blob/master/CHANGES.rst#24-2015-12-03) (@burhan)

## [2016-01-08]
### Changed
- Fixed redis url on docker (@jayfk)
- Fixed docker on windows (@burhan)

## [2016-01-06]
### Added
- You can now enable or disable user registration using the ACCOUNT_ALLOW_REGISTRATION setting. (@ddiazpinto)

### Changed
- Use Postgres 9.5 on docker (@jayfk)

## [2016-01-04]
### Added
- Add Tether.js because [is needed](http://v4-alpha.getbootstrap.com/components/tooltips/#overview) for proper positioning of Bootstrap tooltips (@EricZaporzan)

### Changed
- Minor fixes in the docker documentation (@jayfk)
- Made @burhan a core committer (@pydanny)

## [2015-12-30]
### Changed
- Fixed a bug where the navbar was not displayed correctly (@jvanbrug)

## [2015-12-21]
### Changed
- Added sentry logger to celery config (@jayfk)

## [2015-12-16]
- Update preview 4xx error pages to accept `exception` argument (@theskumar)

## [2015-12-15]
### Changed
- Fix celery worker app name in Procfile (@stepmr)

## [2015-12-13]
### Changed
- Bumped Django to 1.9 (@areski)
- Support opbeat logging with celery (@stepmr)
- Update runtime.txt with PY2 support (@stepmr)

## [2015-12-12]
### Added
- Celery worker to Heroku procfile (@stepmr)

## [2015-12-11]
### Changed
- Fixed issue #436 - cookiecutter variable name was renamed from `celery_support` to `use_celery` in `tests/engine.py` (@luzfcb @otakucode)
- Updated Heroku runtime.txt for python 3.5.1 (@yunti)

## [2015-12-06]
### Changed
- Reorganization of contributors (@burhan)

## [2015-12-01]
### Changed
- Update documentation to include the installation os dependencies before development requirements (@failsafe86)

## [2015-11-29]
### Changed
- Update version of click and python-build (@luzfcb)

## [2015-11-25]
### Changed
- Update version of psutil, ipython (@luzfcb)
- Update version of gunicorn (@audreyr)
- Remove debugging tools from non-generated part of cookiecutter-django, since those are personal prefs (@audreyr)
- Update version of Django in setup.py (@luzfcb)

## [2015-11-24]
### Changed
- Update version of Django, coverage and click (@luzfcb)
- Fixed configuration for Celery in local.py. (@luzfcb @hackebrot)

## [2015-11-23]
### Changed
- Update AngularJS version to 1.4.8 (@luzfcb)
- Update version of cookiecutter, pytest, tox, whitenoise, django-test-plus, django_coverage_plugin, Werkzeug, hitchserve, tornado, unixpackage (@luzfcb)
- Update 'now' date in cookiecutter.json (@luzfcb)
- `sh` package version pinned to `1.11` (@luzfcb)

## [2015-11-22]
### Changed
- Move div class unquote outside the django if tag (@jvanbrug)
- Changed gevent to `1.1rc1` for python 3 users (@jondelmil / @jayfk)

## [2015-11-20]
### Changed
- Using python 3.5 on Heroku/Travis (@bogdal)
- Fixed typo in README (@tedmiston)

## [2015-11-18]
### Added
- Mailhog as a replacement for Maildump (@keybits)

### Removed
- Maildump because it didn't support Python 3 (@keybits)

## [2015-11-17]
### Added
- initial configuration to support opbeat (@burhan)

### Removed
- Took `*.pyc` out of .gitignore, because it's already covered by `*.py[cod]` (@audreyr)

## [2015-11-16]
### Changed
- Cleanup of main README (@burhan)

## [2015-11-15]
### Added
- Added `UserFactory` for users.User tests (@ad-m)

## [2015-11-12]
### Changed
- Update version of django-allauth (@yunti)
- Added a warning in README.rst: ```repo_name must be a valid Python module``` @cdvv7788

### Removed
- remove ```{% load url from future %}``` in templates - deprecated in django 1.9 (@yunti)

## [2015-11-11]
### Added
- Added django_coverage_plugin to measure Django template coverage (@audreyr)

## [2015-11-09]
### Changed
- Now using py.test for our test suite!! (@hackebrot)
- Python version in travis.yml is now correct for the selected version of Django (@show0k)

## [2015-11-08]
### Changed
- bump django-extensions version (@garrypolley)

## [2015-11-07]
### Added
- newrelic support (@amjith)
- DJANGO_SENTRY_DSN to env.example (@jayfk)

### Changed
- Made `post_gen_hook.set_secret_key()` only changes one CHANGEME!!! at a time. (@pydanny)
- Fixed an error where celery couldn't load the sentry DSN from settings (@jayfk)
- Renamed ADMIN_URL to DJANGO_ADMIN_URL in env.example (@ChrisPappalardo)

## [2015-11-06]
### Added
- \*tests\* to `.coveragerc`, because including it is cheating! (@pydanny)
- Binaryornot to cookiecutter-django's own tests because otherwise Python 3 blows up (@audreyr)

### Changed
- `.travis.yml` configuration to support Python 3.4 and 3.5 (@pydanny)
- `.gitignore` configuration so py.test cache files don't show up in git status.

## [2015-11-05]
### Changed
- Update version of django-extensions (@luzfcb)
- Fix gevent requirement for Python 3 (@mcho421)

## [2015-11-04]
### Changed
- Update version of Django, cookiecutter, celery, coverage, django-mailgun, django-redis, factory_boy, flake8, pytest and pytz (@luzfcb)
- Update AngularJS version to 1.4.7 (@luzfcb)
- Update 'now' date in cookiecutter.json (@luzfcb)

## [2015-10-28]
### Changed
- Update deployment-on-heroku.rst for ADMIN_URL (@yunti)

## [2015-10-27]
### Added
- Added sudo: true to the travis file (@MathijsHoogland)

## [2015-10-25]
### Added
- Move current logging config into production.py since it's not useful locally anyway. Used only if not using Sentry. (@audreyr)
- `setup.py` so we can list it on PyPI and therefore displayed on djangopackages.com as compatible with Python 3. (@pydanny)
- Versioning and tagging policy (@pydanny)
- Fixed flake8 issue (@pydanny)

## [2015-10-24]
### Changed
- Update nav in base template to latest Bootstrap 4 version (@audreyr)
- Replaced ADD with COPY in dockerfiles (@audreyr)
- Simplified development dockerfile (@jayfk)
- Moved the docker postgres volume on the development environment to it's own subfolder (@jayfk)
- Renamed DJANGO_CACHE_URL to REDIS_URL (@jayfk / proposed by @pydanny)

## [2015-10-22]
### Removed
- Remove unnecessary .gitkeep in static/images/ (@audreyr)

## [2015-10-21]
### Changed
- Updated requirements (@theskumar)
### Removed
- editorconfig comment that was just a isort settings link (@pydanny)

## [2015-10-19]
### Changed
- On Windows, don't install psycopg2 locally. Still install it in test/prod which are assumed to be Unix. (@audreyr)

## [2015-10-15]
### Changed
- Made `post_gen_hook` function to change secret keys in files more generic (@pydanny)
- Set cryptographically randomized value to `DJANGO_SECRET_KEY` in `env.example` (@pydanny)

## [2015-10-14]
### Added
- Documention of project options (@audreyr)
### Changed
- Added clarification on building for local or production (@MathijsHoogland)
- Whitespace correction in dev.yml (@MathijsHoogland)

## [2015-10-13]
### Changed
- Requirements update (@theskumar)

## [2015-10-11]
### Changed
- Fixed raven issue on development (#302) (@jazztpt)

## [2015-10-05]
### Changed
- Update version of Django, Pillow, hitchselenium, psutil (@luzfcb)

## [2015-10-04]
### Changed
- Remove stray closing tags and fix navbar margin in in base.html (@hairychris)
- Docker docs to be functional and more understandable (@audreyr)

## [2015-09-30]
### Changed
- Fixed Sentry logging with celery (@jayfk)
- Added pep8 and pyflakes to requirements (@jayfk)
- Fixed url() arguments in urls.py because String view arguments to url() is deprecated in django 1.9 (@siauPatrick)
- Update version of cookiecutter, coverage, django-environ, django-extensions, hitchpython, hitchselenium, hitchserve, pytest, pytz, whitenoise (@luzfcb)
- Update the usage example in README (@luzfcb)
- Update 'now' date in cookiecutter.json (@luzfcb)

## [2015-09-29]
### Changed
- Fix RST in Docker docs (@andor-pierdelacabeza)

## [2015-09-27]
### Added
- Added advice on how to persist changes with boot2docker (@jayfk)

###Changed
- Removed duplicate from `CONTRIBUTORS.rst` (@jayfk)

## [2015-09-26]
### Added
- Add .pylintrc and .pep8 (@kaidokert)

### Changed
- Move pep8 rules to setup.cfg (@audreyr)
- Better pep8 rules for exclusion (@audreyr)
- Document all linters (@audreyr)
- Sass linting and improvements to alerts (@audreyr)

## [2015-09-25]
### Changed
- django-mailgun requirement to 0.7.2 (@pydanny)
- Remove commented-out flake8 ignore rule. (@audreyr)

## [2015-09-24]
### Changed
- Add user-uploaded media dir to .gitignore (@audreyr)
- Update .editorconfig to use 2 spaces for html, css, scss, json (@audreyr)
- Have flake8 ignore node_modules dir (@audreyr)

## [2015-09-23]
### Changed
- Add workaround for django-debug-toolbar conflict with Bootstrap 4 (@audreyr)

## [2015-09-22]
### Added
- Add Python version option for deployment (@yunti)

## [2015-09-21]
### Changed
- django-mailgun-redux to django-mailgun, because @pydanny now has commit rights
### Removed
- Excess "loggers" from LOGGING setting (@siauPatrick)

## [2015-09-18]
### Changed
- Major reorganization of docs (@pydanny)
- Fix expanded navbar on mobile (@jayfk)
- Update various requirements (@audreyr)

## [2015-09-17]
### Added
- Fix for wsgi.py for Raven in dev (@yunti)

## [2015-09-15]
### Added
- whitespace to allow proper rendering of RST (@IanLee1521 )

## [2015-09-14]
### Added
- Functionality to delete taskapp if celery isn't going to be used (@pydanny)

### Removed
- Remove unused generated CSS styles (@audreyr)

### Changed
- Use Bootstrap margin utility class `m-b-lg` and remove our custom `navbar-header` class (@audreyr)
- Update Hitch requirements (@audreyr)

## [2015-09-13]
### Removed
- Styles that already exist in Bootstrap 4 (or 3) (@audreyr)

### Changed
- Fix issue #296 - change login.html to use [get_providers](https://github.com/pennersr/django-allauth/blob/master/allauth/socialaccount/templatetags/socialaccount.py#L84-L93) templatetag because ``allauth.socialaccount`` context processor now is [deprecated](http://django-allauth.readthedocs.io/en/latest/changelog.html#from-0-21-0) (@luzfcb)

## [2015-09-09]
### Added
- post_gen_hook to generate a secret key for use in locals.py. You should define your own for production (@pydanny)

## [2015-09-09]
### Added
- htmlcov to gitignore (@pydanny)

## [2015-09-04]
### Added
- Easy deploy Heroku button and app.json file (@bogdal)

## [2015-09-03]
### Added
- For security reasons, we set explicitly the list of allowed hosts (@bogdal)

## [2015-08-31]
### Removed
- Dokku in favor of docker-compose and other modern Django tools (@pydanny)

## [2015-08-30]
### Changed
- Moved from Bootstrap 3 to Bootstrap 4 (@audreyr)
- Slight Reorganization of the README docs (@pydanny)
- Dokku docs are out of the README and in the docs folder (@pydanny)
- Small improvements in ``install_python_dependencies.sh`` and ``install_os_dependencies.sh`` scripts (@luzfcb)
- Update version of django-crispy-forms, django-extensions, django-test-plus, gevent, coverage, hitchpython and hitchtest (@luzfcb)
- Update AngularJS version to 1.4.4 (@luzfcb)
- Update the usage example on README (@luzfcb)

## [2015-08-28]
### Changed
- Switched to django-mailgun-redux so mail doesn't blow up on Python 3 (@pydanny)


## [2015-08-27]
### Changed
- Grunt Updates: use libsass, add postcss (@288)

## [2015-08-20]
### Changed
- requirements files to match current dependency versions (@pydanny)

## [2015-08-18]
### Added
- Docker support and docker-compose (@jayfk)

## [2015-08-12]
### Added
- hitch for end-to-end testing functionality (@crdoconnor)

## [2015-08-09]
### Added
- test coverage, bringing it to 100% (@pydanny)

## 2015-08-08
### Added
- Gitter badge (@pydanny)
### Changed
- Refactor of cookiecutter-django render tests (@burhan)

## [2015-08-06]
### Added
- More test coverage, up to 97% (@pydanny)
- Slight optimization to celery configuration (@jayfk)

## [2015-08-05]
### Added
- Sentry support (@burhan)

### Changed
- Made the user object python 2 and 3 friendly (@pydanny)
- When using maildump, pin gevent. (@audreyr)
- Updated coverage version. (@audreyr)


## [2015-08-04]
### Added
- Better specification of migrations in .coveragerc. (@audreyr)

## [2015-08-03]
### Added
- Instructions for using coverage and generating reports (@audreyr)
- Coverage project-level config file (@audreyr)
- factory-boy package for improved testing  (@pydanny)
- Error message for duplicate usernames in `users.admin.MyUserCreationForm` (@pydanny)
- Tests on `users.admin.MyUserCreationForm` (@pydanny)

### Changed
- update django-all-auth to 0.23.0  (@pydanny)
- update django-test-plus to 1.0.7  (@pydanny)

### Removed
- Unnecessary users/forms.py module (@pydanny)

## [2015-07-30]
### Changed
- update django-floppyforms version to 1.5.2

## [2015-07-29]
### Removed
- Removed legacy permalink decorator from the users.User model. (@pydanny)

## [2015-07-27]
### Removed
- removed django-allauth template context processors because is deprecated now. see: https://github.com/pennersr/django-allauth/commit/634f4fe60e67c266aadcfba2981074f005db340c (@burhan)

### Changed
- update version of ipython, django-allauth (@luzfcb)
- update version of django-braces, django-floppyforms, django-model-utils (#287)(@burhan)

## [2015-07-21]
### Changed
- memcached is as a cache is replace with redis (#258)(@burhan)

## [2015-07-18]
### Changed
- Heroku deployment docs (@stepmr)
    - Heroku's free postgres tier is now "hobby-dev"
    - pg:backups require a scheduled time
    - add missing Mailgun API key
    - Django recommends setting the PYTHONHASHSEED environment variable to random. See: https://docs.djangoproject.com/en/1.8/howto/deployment/checklist/#python-options
    - Use openssl to generate a secure, random secret_key


## [2015-07-17]
### Added
- @models.permalink decorator to User.get_absolute_url() method

### Fixed
- Broken user_form.html (@pydanny)

## [2015-07-16]
### Added
- django-test-plus (@pydanny)
- option use maildump instead of ConsoleEmailHandler (@burhan)
- Changelog.md (@pydanny)

### Fixed
- where 'DEFAULT_FROM_EMAIL' was used to cast the value (@jayfk)

### Removed
- unnecessary header block tag and 'user:' prefix. (@pydanny)
